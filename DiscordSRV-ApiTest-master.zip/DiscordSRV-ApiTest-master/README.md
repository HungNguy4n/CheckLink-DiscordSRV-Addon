# DiscordSRV-ApiTest
Example usage of DiscordSRV's API

## [See DiscordSRV's wiki for dependency information](https://docs.discordsrv.com/#developers)
